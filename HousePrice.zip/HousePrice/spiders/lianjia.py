# -*- coding: utf-8 -*-
from scrapy.spiders import CrawlSpider

from HousePrice.items import HousepriceItem


class LianjiaSpider(CrawlSpider):
    name = 'lianjia'
    allowed_domains = ['wh.lianjia.com/chengjiao/']
    start_urls = ['https://wh.lianjia.com/chengjiao/pg1/']

    def parse1(self, response):
        # size匹配的内容很关键，决定输出的item的格式是横还是竖
        size=response.css('.listContent li')
        # 遍历爬取
        for each in size:
            item = HousepriceItem()
            url=each
            xiaoqu = each.css('.title a::text').re('(.*?)\s\d室')
            price = each.css('.address .totalPrice span::text').extract()
            avg_price = each.css('.flood .unitPrice span::text').re('(\d+)')
            huxing = each.css('.title a::text').re('\d室\d厅')
            area = each.css('.title a::text').re('厅\s(\d.*?平米)')
            date = each.css('.dealDate::text').extract()
            item['xiaoqu'] = xiaoqu
            item['price'] = price
            item['avg_price'] = avg_price
            item['area'] = area
            item['huxing'] = huxing
            item['date'] = date

            yield item


        # page = response.xpath("//div[@class='page-box house-lst-page-box'][@page-data]").re("\d+")
        # p = re.compile(r'[^\d]+')
        # if len(page) > 1 and page[0] != page[1]:
        #     next_page = p.match(response.url).group() + str(int(page[1]) + 1)
        #     print(next_page + "*********************")
        #     next_page = response.urljoin(next_page)
        #     yield scrapy.Request(next_page, callback=self.parse)



